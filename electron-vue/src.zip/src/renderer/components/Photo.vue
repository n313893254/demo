<template lang="html">
  <div class="">
    <div class="menu-wrapper-left">
      <div class="menu" v-if="leftMenuSeen">
        <div  @click="set('视频')">
        	<router-link class="button" to="/VideoList"><img src="../assets/src/history_08.png"></router-link>
        </div>
        <div  @click="set('照片')">
        	<router-link class="button" to="/Photo"><img src="../assets/src/history_06.png"></router-link>
        </div>
        <div  @click="set('诗篇')">
        	<router-link class="button" to="/PoetryList"><img src="../assets/src/history_10.png"></router-link>
        </div>
        <div  @click="set('个人著作')">
        	<router-link class="button" to="/WritingList"><img src="../assets/src/history_03.png"></router-link>
        </div>
        <div class="button" @click="closeLeftMenu()"><img src="../assets/src/book_35.png"></div>
      </div>
      <div class="menu" v-else>
        <div class="button" @click="openLeftMenu()"><img src="../assets/src/book_35.png"></div>
      </div>
    </div>
    <p>照片列表</p>
    <div class="mid">
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
      <div class="photomodel">
       <div class="photo"><img src="../assets/src/photo.jpg"></div>
       <div class="biaoti"><p>40年代，关山月夫妇（左二，左三）、七...</p></div>
      </div>
    </div>
    </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Photo',
  computed: {
    title () {
      return this.$store.state.photoTitle
    },
    leftMenuSeen () {
      return this.$store.state.leftMenuSeen
    },
    photos () {
      return this.$store.state.photos.slice(0, 6)
    }
  },
  methods: {
    set (value) {
      return this.$store.commit('setPhotoList', value)
    },
    openLeftMenu () {
      return this.$store.commit('openLeftMenu')
    },
    closeLeftMenu () {
      return this.$store.commit('closeLeftMenu')
    }
  },
  created: function () {
    this.$store.commit('setMenuBarSeen', true)
  }
}
</script>

<style lang="css" scoped>
.mid{
	width: 84vw;
	height: 90vh;
	margin-left: 4.5vw;
}
.menu-wrapper-left {
  position: fixed;
  left: 1vh;
  bottom: 1vw;
}
.photomodel{
	width: 16vw;
	height: 28vh;
	margin-top: 6vh;
	float: left;
}
.photo{
	width: 14vw;
	height: 14vh;
	margin: 1vw;
	border-radius: 15px;
	background-color: #ffffff;
}
.photo img{
	width: 13vw;
	height: 13vh;
	margin-left: 0.5vw ;
	margin-top: 0.5vh;
}
.biaoti{
	width: 13.5vw;
	height:8.5vh;
	margin: 1.5vw;
	background-size: contain;
	background-image: url(../assets/src/lable_11.png);
	background-repeat: no-repeat;
	background-position: 100% ,100%;
}
p{
	color: #FBFC7D;
	text-align: center;
	font-size: 1vw;
	padding-top: 1.5vh;
}
</style>
